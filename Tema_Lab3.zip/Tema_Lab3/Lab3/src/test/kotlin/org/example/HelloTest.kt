package org.example

import org.junit.Test
import kotlin.test.assertEquals

class HelloTest {

}
